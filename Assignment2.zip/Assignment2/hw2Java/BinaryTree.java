package Assignments.Assignment2.hw2Java;

class BinaryTree<T extends Number> { /* nature abhors a vacuum */ }

