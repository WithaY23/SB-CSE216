package Assignments.Assignment2.hw2Java;

class Point extends Shape
{
    public Point(float x, float y){super(x,y);}

    @Override
    P center()
    {
        return p;
    }

    @Override
    float area()
    {
        return 0;
    }


}
